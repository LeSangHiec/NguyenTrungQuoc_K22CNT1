import React from 'react'

export default function NtqUseContext2() {
  return (
    <div className={theme + 'm-3'}>
        <h2>NtqUseContext2</h2>
        <p>
            <b>2210900119</b>
            <b>Nguyễn Trung Quốc</b>
            <b>K22CNT1</b>
        </p>
    </div>
  )
}
