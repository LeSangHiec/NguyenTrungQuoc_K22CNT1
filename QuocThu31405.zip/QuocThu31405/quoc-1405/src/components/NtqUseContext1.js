import React from 'react'
import NtqUseContext2 from './NtqUseContext2'

export default function NtqUseContext1() {
  return (
    <div className='m-3'>
        <h2>NtqUseContext2</h2>
        <NtqUseContext2 />
    </div>
  )
}
